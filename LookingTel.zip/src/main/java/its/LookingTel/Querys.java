/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package its.LookingTel;

import java.util.ArrayList;

/**
 *
 * @author Guest Mode
 */
public class Querys {
    
    // Gestionar Usuario
    
     void IniciarSesion(String correo_electronico,String contraseña){
         
     }
    
     void Registrarse_Usuario(Usuario usuario){
         
     }
     void Recuperar_Contraseña_Usuario(String correo_electronico){
         
     }
     
     Usuario Consultar_Usuario(int Id){
         
     }
     
     Usuario Consultar_Usuario(String correo_electronico){
         
     }
     
     void Borrar_Usuario_Admin(String correo_electronico){
         
     }
     
     void Borrar_Usuario_Admin(int Id){
         
     }
     void Actualizar_Usuario(String correo_electronico){
         
     }
     void Actualizar_Usuario(int Id){
         
     }
     
    
    //Gestionar Condominios
    
     ArrayList<Condominio> Consultar_Condominios_Usuario(){
         
     }
     Condominio Consultar_Condominio_Admin(int Id){
         
     }
     Condominio Consultar_Condominio_Admin(String CIF){
         
     }
     void Registrar_Condominio_Admin(Condominio condomnio){
         
     }
     void Eliminar_Condominio_Admin(String CIF){
         
     }
     void Eliminar_Condominio_Admin(int Id){
         
     }
     void Actualizar_Condominio_Admin(String CIF){
         
     }
     void Actualizar_Condominio_Admin(int Id){
         
     }
     
    
     
    //Gestionar Reservaciones
    
      ArrayList<Reservacion> Consultar_Reservaciones_Usuario(int Id){
         
     }
      
      Reservacion Consultar_Reservacion_Admin(String CIF){
         
     }
      
      void  Registrar_Reservacion_Usuario(int Id_Usuario,int Id_Condominio){
         
     }
      
      void Actualizar_Reservacion(String CIF){
          
      }
      
      void Eliminar_Reservacion(String CIF){
          
      }
    
    
    
}
